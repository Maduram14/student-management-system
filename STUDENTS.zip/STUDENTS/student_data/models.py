from django.db import models
from django.utils import timezone

# Choices for payment method
PAYMENT_METHOD_CHOICES = [
    ('Cash', 'Cash'),
    ('GPay', 'GPay'),
]

class Student(models.Model):
    register_number = models.CharField(max_length=20, null=True, blank=True)
    admission_date = models.DateField(null=True, blank=True)
    name = models.CharField(max_length=200)
    course = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=15)
    address = models.TextField(blank=True, null=True)
    total_fees = models.DecimalField(max_digits=10, decimal_places=2)
    paid = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    last_payment_date = models.DateField(null=True, blank=True)
    installment_payment = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    @property
    def balance(self):
        """Return remaining balance."""
        return self.total_fees - self.paid

    def __str__(self):
        return f"{self.name} ({self.register_number})"


class PaymentHistory(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='payment_history')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(default=timezone.now)  # automatically stores date & time
    method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='Cash')

    def __str__(self):
        return f"{self.student.name} - ₹{self.amount} ({self.method}) on {self.date.strftime('%Y-%m-%d %H:%M')}"