from django.apps import AppConfig

class StudentDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'student_data'  # <-- must match folder name
