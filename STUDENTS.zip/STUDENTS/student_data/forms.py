from django import forms
from .models import Student, PaymentHistory
from django.utils import timezone

# ----------------------
# Form to create/edit Student
# ----------------------
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            'register_number',
            'name',
            'course',
            'mobile_number',
            'address',
            'admission_date',
            'total_fees'
        ]
        labels = {
            'register_number': 'Register Number',
            'name': 'Student Name',
            'course': 'Course',
            'mobile_number': 'Mobile Number',
            'address': 'Address',
            'admission_date': 'Admission Date',
            'total_fees': 'Total Fees',
        }
        widgets = {
            'register_number': forms.TextInput(attrs={'placeholder': 'Enter register number'}),
            'name': forms.TextInput(attrs={'placeholder': 'Enter student name'}),
            'course': forms.TextInput(attrs={'placeholder': 'Enter course name'}),
            'mobile_number': forms.TextInput(attrs={'placeholder': 'Enter mobile number'}),
            'address': forms.Textarea(attrs={'placeholder': 'Enter address', 'rows': 3}),
            'admission_date': forms.DateInput(attrs={'type': 'date', 'placeholder': 'Select admission date'}),
            'total_fees': forms.NumberInput(attrs={'placeholder': 'Enter total fees'}),
        }

    def clean_register_number(self):
        reg_num = self.cleaned_data.get('register_number')
        return reg_num.upper() if reg_num else reg_num


# ----------------------
# Form to record Payment
# ----------------------
class PaymentForm(forms.ModelForm):
    PAYMENT_METHOD_CHOICES = [
        ('Cash', 'Cash'),
        ('GPay', 'GPay'),
    ]

    method = forms.ChoiceField(
        choices=PAYMENT_METHOD_CHOICES,
        label="Payment Method",
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = PaymentHistory
        fields = ['amount', 'method']
        labels = {
            'amount': 'Payment Amount',
        }
        widgets = {
            'amount': forms.NumberInput(attrs={
                'placeholder': 'Enter payment amount',
                'min': '0.01',
                'step': '0.01'
            }),
        }

    def save(self, commit=True, student=None):
        """
        Save payment with datetime, amount, and method.
        """
        if student is None:
            raise ValueError("Student instance is required to save payment.")

        payment_amount = self.cleaned_data.get('amount', 0)
        payment_method = self.cleaned_data.get('method', 'Cash')

        if payment_amount <= 0:
            return None  # Invalid amount

        # Create payment record
        payment = PaymentHistory.objects.create(
            student=student,
            amount=payment_amount,
            method=payment_method,
            payment_datetime=timezone.now()  # current date & time
        )

        # Update student's total paid and last payment date
        student.paid += payment_amount
        student.last_payment_date = timezone.now().date()
        if commit:
            student.save()

        return payment