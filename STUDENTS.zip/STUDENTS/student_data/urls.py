from django.urls import path
from . import views

urlpatterns = [
    # ----------------------
    # Authentication
    # ----------------------
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # ----------------------
    # Dashboard
    # ----------------------
    path('', views.dashboard, name='dashboard'),

    # ----------------------
    # Student Register (Form + Table)
    # ----------------------
   # urls.py
    path('students/', views.student_register, name='student_register'),

    # ----------------------
    # Student CRUD
    # ----------------------
    path('student/<int:pk>/edit/', views.edit_student, name='edit_student'),
    path('student/<int:pk>/delete/', views.delete_student, name='delete_student'),

    # ----------------------
    # Payments
    # ----------------------
    path('payment/<int:pk>/', views.record_payment, name='record_payment'),
    path('payment/<int:pk>/history/', views.payment_history, name='payment_history'),
    path('payment/<int:pk>/pdf/', views.render_pdf_view, name='render_pdf'),
]