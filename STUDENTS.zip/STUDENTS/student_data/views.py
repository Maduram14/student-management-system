from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.template.loader import get_template
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils import timezone
from django.db.models import Sum, Q
from django.db.models.functions import ExtractMonth
from xhtml2pdf import pisa

from .models import Student, PaymentHistory
from .forms import StudentForm, PaymentForm

# ----------------------
# Authentication Views
# ----------------------
def login_view(request):
    next_url = request.GET.get('next') or request.POST.get('next')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
                if not next_url.startswith('/login'):
                    return redirect(next_url)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form, 'next': next_url or ''})

def logout_view(request):
    logout(request)
    return redirect('login')


# ----------------------
# Dashboard (summary + monthly payments chart)
# ----------------------
@login_required
def dashboard(request):
    total_students = Student.objects.count()
    total_fees_sum = Student.objects.aggregate(total=Sum('total_fees'))['total'] or 0
    total_paid = PaymentHistory.objects.aggregate(total=Sum('amount'))['total'] or 0
    total_balance = total_fees_sum - total_paid

    monthly_labels = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    monthly_totals = [0]*12

    payments = PaymentHistory.objects.annotate(month=ExtractMonth('date')) \
                .values('month') \
                .annotate(total=Sum('amount'))

    for p in payments:
        month_index = p['month'] - 1
        monthly_totals[month_index] = float(p['total'] or 0)

    context = {
        'total_students': total_students,
        'total_paid': total_paid,
        'total_balance': total_balance,
        'monthly_labels': monthly_labels,
        'monthly_totals': monthly_totals,
    }

    return render(request, 'dashboard.html', context)


# ----------------------
# Student CRUD + Search
# ----------------------
@login_required
def student_register(request):
    search_query = request.GET.get('q', '')  # Get search query

    # Filter students by name (case-insensitive)
    if search_query:
        students = Student.objects.filter(name__icontains=search_query)
    else:
        students = Student.objects.all()

    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_register')
    else:
        form = StudentForm()

    students_info = []
    for student in students:
        total_paid = PaymentHistory.objects.filter(student=student).aggregate(total=Sum('amount'))['total'] or 0
        balance = max(student.total_fees - total_paid, 0)
        overpaid = max(total_paid - student.total_fees, 0)
        students_info.append({
            'student': student,
            'total_paid': total_paid,
            'balance': balance,
            'overpaid': overpaid,
        })

    context = {
        'form': form,
        'students_info': students_info,
        'search_query': search_query,  # Pass query back to template
    }
    return render(request, 'student_register.html', context)


@login_required
def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_register')
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})


@login_required
def edit_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student_register')
    else:
        form = StudentForm(instance=student)
    return render(request, 'edit_student.html', {'form': form, 'student': student})


@login_required
def delete_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    student.delete()
    return redirect('student_register')


# ----------------------
# Record Payment
# ----------------------
@login_required
def record_payment(request, pk):
    student = get_object_or_404(Student, pk=pk)
    total_paid = PaymentHistory.objects.filter(student=student).aggregate(total=Sum('amount'))['total'] or 0
    balance = max(student.total_fees - total_paid, 0)

    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            payment_method = form.cleaned_data['method']
            payment_datetime_str = request.POST.get('payment_datetime')
            payment_datetime = timezone.datetime.fromisoformat(payment_datetime_str) if payment_datetime_str else timezone.now()

            if amount <= 0 or amount > balance:
                form.add_error('amount', f'Payment must be > 0 and ≤ remaining balance ₹{balance:.2f}')
            else:
                PaymentHistory.objects.create(
                    student=student,
                    amount=amount,
                    method=payment_method,
                    date=payment_datetime
                )
                student.paid += amount
                student.last_payment_date = payment_datetime.date()
                student.save()
                return redirect('payment_history', pk=student.pk)
    else:
        form = PaymentForm()

    return render(request, 'record_payment.html', {
        'student': student,
        'form': form,
        'balance': balance,
        'total_paid': total_paid,
    })


# ----------------------
# Payment History
# ----------------------
@login_required
def payment_history(request, pk):
    student = get_object_or_404(Student, pk=pk)
    payments = PaymentHistory.objects.filter(student=student).order_by('-date')
    return render(request, 'payment_history.html', {'student': student, 'payments': payments})


# ----------------------
# Generate PDF
# ----------------------
@login_required
def render_pdf_view(request, pk):
    student = get_object_or_404(Student, pk=pk)
    today = timezone.now().date()

    payments_qs = PaymentHistory.objects.filter(student=student).order_by('date')
    running_balance = student.total_fees
    payments = []
    for p in payments_qs:
        payments.append({
            'date': p.date,
            'amount': p.amount,
            'method': p.method,
            'balance_after': max(running_balance - p.amount, 0)
        })
        running_balance -= p.amount

    total_paid = payments_qs.aggregate(total=Sum('amount'))['total'] or 0
    balance = max(student.total_fees - total_paid, 0)
    overpaid = max(total_paid - student.total_fees, 0)

    context = {
        'student': student,
        'today': today,
        'total_paid': total_paid,
        'balance': balance,
        'overpaid': overpaid,
        'payments': payments,
    }

    template_path = 'payment_pdf.html'
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'filename="payment_{student.id}.pdf"'

    template = get_template(template_path)
    html = template.render(context)
    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse('PDF generation error <pre>' + html + '</pre>')

    return response